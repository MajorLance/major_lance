import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import AdminPage from "./pages/AdminPage";
import { AccountPage, BidHistoryPage, FaqPage, UpcomingRoundsPage, WalletPage, WinnersPage, WithdrawalPage } from "./pages/InternalPages";
import "./compact-density.css";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/saldo"} component={WalletPage} />
      <Route path={"/saque"} component={WithdrawalPage} />
      <Route path={"/historico"} component={BidHistoryPage} />
      <Route path={"/proximas-rodadas"} component={UpcomingRoundsPage} />
      <Route path={"/vencedores"} component={WinnersPage} />
      <Route path={"/duvidas"} component={FaqPage} />
      <Route path={"/conta"} component={AccountPage} />
      <Route path={"/admin"} component={AdminPage} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
